const content = [
    {
        thumbnail: "gambar/gambar.jpg, gambar.png",
        title: "Getting Started with JavaScript",
        category: "JavaScript",
        content: "con/content1.html"
    },
    {
        thumbnail: "gambar/gambar2.jpg",
        title: "CSS Flexbox Guide",
        category: "CSS",
        content: "con/content2.html"
    },
    {
        thumbnail: "gambar/gambar3.png",
        title: "HTML5 Semantic Elements",
        category: "HTML",
        content: "con/content3.html"
    },
    {
        title: "Responsive Design Principles",
        category: "CSS",
        content: "con/content4.html"
    }
];