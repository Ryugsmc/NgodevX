const tem = [
    {
        title: "Basic HTML Template",
        category: "HTML",
        tem: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Hello World</h1>
</body>
</html>`
    },
    {
        title: "CSS Grid Layout",
        category: "CSS",
        tem: `.container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
}`
    },
    {
        title: "JavaScript Event Listener",
        category: "JavaScript",
        tem: `document.getElementById('myButton').addEventListener('click', function() {
    alert('Button clicked!');
});`
    }
];