document.addEventListener('DOMContentLoaded', function() {
    // Sidebar elements
    const sidebar = document.getElementById('sidebar');
    const menuBtn = document.getElementById('menuBtn');
    const closeBtn = document.getElementById('closeSidebar');
    const mainContent = document.getElementById('mainContent');
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    document.body.appendChild(overlay);

    // Toggle sidebar
    function toggleSidebar(show) {
        if (show) {
            sidebar.classList.add('show');
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        } else {
            sidebar.classList.remove('show');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    // Event listeners
    menuBtn.addEventListener('click', function() {
        toggleSidebar(true);
    });

    closeBtn.addEventListener('click', function() {
        toggleSidebar(false);
    });

    overlay.addEventListener('click', function() {
        toggleSidebar(false);
    });

    // Theme Toggle
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = themeToggle.querySelector('i');
    
    function setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        
        if (theme === 'dark') {
            themeIcon.className = 'fas fa-sun';
        } else {
            themeIcon.className = 'fas fa-moon';
        }
    }
    
    themeToggle.addEventListener('click', function() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        setTheme(newTheme);
    });
    
    // Load saved theme
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);
    
    // Load content
    const contentContainer = document.getElementById('contentContainer');
    content.forEach(item => {
        const card = document.createElement('div');
        card.className = 'card';
        
        let imgHtml = '';
        if (item.thumbnail) {
            const thumbnails = item.thumbnail.split(', ');
            imgHtml = `<img src="${thumbnails[0]}" alt="${item.title}" class="card-img">`;
        }
        
        card.innerHTML = `
            ${imgHtml}
            <div class="card-body">
                <span class="card-category">${item.category}</span>
                <h3 class="card-title">${item.title}</h3>
                <p class="card-text">${item.content}</p>
                <a href="${item.content}" class="btn">View</a>
            </div>
        `;
        contentContainer.appendChild(card);
    });
    
    // Load templates
    const templateContainer = document.getElementById('templateContainer');
    tem.forEach(item => {
        const card = document.createElement('div');
        card.className = 'card';
        
        card.innerHTML = `
            <div class="card-body">
                <span class="card-category">${item.category}</span>
                <h3 class="card-title">${item.title}</h3>
                <pre><code>${item.tem}</code></pre>
                <div class="template-actions">
                    <button class="btn view-template">View</button>
                    <button class="btn copy-template">Copy</button>
                    ${item.category.toLowerCase().includes('html') ? '<button class="btn run-template">Run</button>' : ''}
                </div>
            </div>
        `;
        templateContainer.appendChild(card);
    });
    
    // Load categories in sidebar
    const sidebarCategories = document.getElementById('sidebarCategories');
    const allCategories = [...new Set(content.map(item => item.category).concat(tem.map(item => item.category)))];
    allCategories.forEach(category => {
        const categoryElement = document.createElement('span');
        categoryElement.className = 'sidebar-category';
        categoryElement.textContent = category;
        categoryElement.addEventListener('click', () => {
            filterByCategory(category);
            toggleSidebar(false);
        });
        sidebarCategories.appendChild(categoryElement);
    });
    
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    
    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') performSearch();
    });
    
    // Template actions
    templateContainer.addEventListener('click', function(e) {
        if (e.target.classList.contains('view-template')) {
            const templateContent = e.target.closest('.card').querySelector('pre code').textContent;
            alert(templateContent);
        } else if (e.target.classList.contains('copy-template')) {
            const templateContent = e.target.closest('.card').querySelector('pre code').textContent;
            navigator.clipboard.writeText(templateContent);
            alert('Template copied to clipboard!');
        } else if (e.target.classList.contains('run-template')) {
            const templateContent = e.target.closest('.card').querySelector('pre code').textContent;
            const newWindow = window.open();
            newWindow.document.write(templateContent);
            newWindow.document.close();
        }
    });
});

function filterByCategory(category) {
    const contentCards = document.querySelectorAll('.content-grid .card');
    const templateCards = document.querySelectorAll('.template-grid .card');
    
    contentCards.forEach(card => {
        const cardCategory = card.querySelector('.card-category').textContent;
        card.style.display = cardCategory === category ? 'block' : 'none';
    });
    
    templateCards.forEach(card => {
        const cardCategory = card.querySelector('.card-category').textContent;
        card.style.display = cardCategory === category ? 'block' : 'none';
    });
}

function performSearch() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const contentCards = document.querySelectorAll('.content-grid .card');
    const templateCards = document.querySelectorAll('.template-grid .card');
    
    contentCards.forEach(card => {
        const title = card.querySelector('.card-title').textContent.toLowerCase();
        const category = card.querySelector('.card-category').textContent.toLowerCase();
        const text = card.querySelector('.card-text').textContent.toLowerCase();
        
        card.style.display = title.includes(searchTerm) || category.includes(searchTerm) || text.includes(searchTerm) ? 'block' : 'none';
    });
    
    templateCards.forEach(card => {
        const title = card.querySelector('.card-title').textContent.toLowerCase();
        const category = card.querySelector('.card-category').textContent.toLowerCase();
        const code = card.querySelector('code').textContent.toLowerCase();
        
        card.style.display = title.includes(searchTerm) || category.includes(searchTerm) || code.includes(searchTerm) ? 'block' : 'none';
    });
}