document.addEventListener('DOMContentLoaded', function() {
    // Theme Toggle
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = themeToggle.querySelector('i');
    
    function setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        
        if (theme === 'dark') {
            themeIcon.className = 'fas fa-sun';
        } else {
            themeIcon.className = 'fas fa-moon';
        }
    }
    
    themeToggle.addEventListener('click', function() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        setTheme(newTheme);
    });
    
    // Load saved theme
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);
    
    // Load videos
    const videoContainer = document.getElementById('videoContainer');
    const categoriesContainer = document.getElementById('categoriesContainer');
    
    // Extract all unique categories
    const allCategories = [...new Set(cvid.map(video => video.category))];
    
    // Create "All" category
    const allCategory = document.createElement('span');
    allCategory.className = 'category';
    allCategory.textContent = 'All';
    allCategory.addEventListener('click', () => {
        filterVideos('All');
    });
    categoriesContainer.appendChild(allCategory);
    
    // Create category filters
    allCategories.forEach(category => {
        const categoryElement = document.createElement('span');
        categoryElement.className = 'category';
        categoryElement.textContent = category;
        categoryElement.addEventListener('click', () => {
            filterVideos(category);
        });
        categoriesContainer.appendChild(categoryElement);
    });
    
    // Load all videos initially
    loadVideos(cvid);
    
    // Video Popup elements
    const videoPopup = document.getElementById('videoPopup');
    const closePopup = document.getElementById('closePopup');
    const videoPlayer = document.getElementById('videoPlayer');
    const playPauseBtn = document.getElementById('playPauseBtn');
    let isPlaying = true;
    
    // Close popup
    closePopup.addEventListener('click', function() {
        videoPopup.classList.remove('active');
        videoPlayer.src = '';
    });
    
    // Play/Pause button
    playPauseBtn.addEventListener('click', function() {
        if (isPlaying) {
            videoPlayer.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
        } else {
            videoPlayer.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*');
            playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
        }
        isPlaying = !isPlaying;
    });
    
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    
    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') performSearch();
    });
    
    // Functions
    function loadVideos(videos) {
        videoContainer.innerHTML = '';
        
        videos.forEach(video => {
            const videoCard = document.createElement('div');
            videoCard.className = 'video-card';
            
            // Get YouTube thumbnail if YouTube link
            let thumbnailUrl = '';
            if (video.thumbnail) {
                thumbnailUrl = video.thumbnail;
            } else if (video.linkvid.includes('youtube.com') || video.linkvid.includes('youtu.be')) {
                const videoId = extractYouTubeId(video.linkvid);
                if (videoId) {
                    thumbnailUrl = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
                }
            }
            
            videoCard.innerHTML = `
                <div class="video-thumbnail">
                    ${thumbnailUrl ? `<img src="${thumbnailUrl}" alt="${video.title}">` : ''}
                </div>
                <div class="video-info">
                    <span class="video-category">${video.category}</span>
                    <h3 class="video-title">${video.title}</h3>
                    <div class="video-actions">
                        <button class="video-btn watch-btn" data-video="${video.linkvid}">
                            <i class="fas fa-play"></i> Watch
                        </button>
                        <a href="${video.linkvid}" target="_blank" class="video-btn open-btn">
                            <i class="fas fa-external-link-alt"></i> Open
                        </a>
                    </div>
                </div>
            `;
            
            videoContainer.appendChild(videoCard);
        });
        
        // Add event listeners to watch buttons
        document.querySelectorAll('.watch-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const videoUrl = this.getAttribute('data-video');
                playVideo(videoUrl);
            });
        });
    }
    
    function playVideo(url) {
        let embedUrl = url;
        
        // Convert YouTube URL to embed URL
        if (url.includes('youtube.com') || url.includes('youtu.be')) {
            const videoId = extractYouTubeId(url);
            if (videoId) {
                embedUrl = `https://www.youtube.com/embed/${videoId}?enablejsapi=1`;
            }
        } else if (url.includes('drive.google.com')) {
            // Handle Google Drive links
            embedUrl = url.replace('/view', '/preview');
        }
        
        videoPlayer.src = embedUrl;
        videoPopup.classList.add('active');
        isPlaying = true;
        playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
    }
    
    function extractYouTubeId(url) {
        const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
        const match = url.match(regExp);
        return (match && match[2].length === 11) ? match[2] : null;
    }
    
    function filterVideos(category) {
        if (category === 'All') {
            loadVideos(cvid);
        } else {
            const filteredVideos = cvid.filter(video => video.category === category);
            loadVideos(filteredVideos);
        }
    }
    
    function performSearch() {
        const searchTerm = searchInput.value.toLowerCase();
        const filteredVideos = cvid.filter(video => 
            video.title.toLowerCase().includes(searchTerm) || 
            video.category.toLowerCase().includes(searchTerm)
        );
        loadVideos(filteredVideos);
    }
});