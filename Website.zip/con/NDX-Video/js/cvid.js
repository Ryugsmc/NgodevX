const cvid = [
    {
        title: "Introduction to JavaScript",
        category: "Programming",
        linkvid: "https://www.youtube.com/watch?v=W6NZfCO5SIk",
        thumbnail: "https://img.youtube.com/vi/W6NZfCO5SIk/hqdefault.jpg"
    },
    {
        title: "CSS Grid Tutorial",
        category: "Web Design",
        linkvid: "https://www.youtube.com/watch?v=9zBsdzdE4sM",
        thumbnail: "https://img.youtube.com/vi/9zBsdzdE4sM/hqdefault.jpg"
    },
    {
        title: "React Crash Course",
        category: "Programming",
        linkvid: "https://www.youtube.com/watch?v=w7ejDZ8SWv8",
        thumbnail: "https://img.youtube.com/vi/w7ejDZ8SWv8/hqdefault.jpg"
    },
    {
        title: "Photoshop Tutorial",
        category: "Design",
        linkvid: "https://www.youtube.com/watch?v=IyR_uYsRdPs",
        thumbnail: "https://img.youtube.com/vi/IyR_uYsRdPs/hqdefault.jpg"
    },
    {
        title: "Google Drive File",
        category: "Document",
        linkvid: "https://drive.google.com/file/d/1D3AmP1JXZ3C4C4C4C4C4C4C4C4C4C4C4C4C4C4C4/view",
        thumbnail: ""
    },
    {
        title: "Pinterest Design Ideas",
        category: "Design",
        linkvid: "https://www.pinterest.com/pin/1234567890/",
        thumbnail: ""
    }
];